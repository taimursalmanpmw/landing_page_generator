# CHANGELOG.md

## 1.0.0 (Jan 26, 2019)

First release
